<script setup lang="ts">
import { RouterView } from 'vue-router'
</script>

<template>
  <div class="min-h-screen bg-white text-gray-900 bg-gray-50">
    <RouterView />
  </div>
</template>

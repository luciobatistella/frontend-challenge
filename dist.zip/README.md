# Sistema de Pedidos - Mercado Eletrônico

Uma aplicação Vue3 moderna e responsiva para visualização e gerenciamento de pedidos, consumindo dados da API do Mercado Eletrônico.

## 🚀 Tecnologias Utilizadas

- **Vue 3** - Framework JavaScript progressivo
- **TypeScript** - Superset tipado do JavaScript
- **Vite** - Build tool rápida e moderna
- **Tailwind CSS** - Framework CSS utilitário
- **Vue Router** - Roteamento oficial do Vue
- **Vitest** - Framework de testes unitários
- **ESLint + Prettier** - Linting e formatação de código

## 📋 Funcionalidades

- ✅ Listagem de pedidos com informações resumidas
- ✅ Visualização detalhada de pedidos individuais
- ✅ Design responsivo para todos os dispositivos
- ✅ Componentes reutilizáveis e modulares
- ✅ Integração com API externa
- ✅ Testes unitários abrangentes
- ✅ Arquitetura escalável e organizada

## 🏗️ Arquitetura do Projeto

```
src/
├── components/          # Componentes reutilizáveis
│   ├── layout/         # Componentes de layout (Header, Footer)
│   └── ui/             # Componentes de interface (Button, Card, Input)
├── views/              # Páginas da aplicação
│   ├── HomeView.vue    # Lista de pedidos
│   └── OrderDetailView.vue # Detalhes do pedido
├── router/             # Configuração de rotas
├── assets/             # Recursos estáticos (CSS, imagens)
└── main.ts             # Ponto de entrada da aplicação
```

## 🔗 API Integration

A aplicação consome dados da API do Mercado Eletrônico:
- **Endpoint**: `https://api.mercadoe.space/orders/1`
- **Método**: GET
- **Resposta**: Dados completos do pedido incluindo header, fornecedor e endereços

## 🛠️ Como Instalar e Rodar o Projeto

### Pré-requisitos

- Node.js 18.0.0 ou superior
- npm ou yarn

### Instalação

1. Clone o repositório:
```bash
git clone <url-do-repositorio>
cd mercadoeletronico
```

2. Instale as dependências:
```bash
npm install
```

3. Execute o servidor de desenvolvimento:
```bash
npm run dev
```

4. Acesse a aplicação em: `http://localhost:5173`

## 📜 Scripts Disponíveis

### Desenvolvimento
```bash
npm run dev          # Inicia o servidor de desenvolvimento
npm run build        # Gera build de produção
npm run preview      # Visualiza o build de produção
```

### Qualidade de Código
```bash
npm run test:unit    # Executa testes unitários
npm run lint         # Executa linting do código
npm run format       # Formata o código com Prettier
npm run type-check   # Verifica tipos TypeScript
```

## 🧪 Testes

O projeto inclui testes unitários abrangentes usando Vitest e Vue Test Utils:

```bash
# Executar todos os testes
npm run test:unit

# Executar testes em modo watch
npm run test:unit -- --watch

# Executar testes com coverage
npm run test:unit -- --coverage
```

## 📱 Design Responsivo

A aplicação foi desenvolvida com foco em responsividade, utilizando:

- **Mobile First**: Design otimizado para dispositivos móveis
- **Breakpoints Tailwind**: Sistema de breakpoints consistente
- **Componentes Flexíveis**: Adaptam-se automaticamente a diferentes tamanhos
- **Navegação Responsiva**: Menu hambúrguer para dispositivos móveis

### Breakpoints Utilizados:
- `sm`: 640px e acima
- `md`: 768px e acima
- `lg`: 1024px e acima
- `xl`: 1280px e acima

## 🎨 Sistema de Design

### Cores Principais
- **Primary**: Azul (#3b82f6)
- **Secondary**: Cinza (#64748b)
- **Success**: Verde
- **Error**: Vermelho

### Componentes Base
- **BaseButton**: Botão reutilizável com variantes
- **BaseCard**: Card flexível com slots
- **BaseInput**: Input com validação e estados

## 🚀 Deploy

### Preparação para Deploy

1. Gere o build de produção:
```bash
npm run build
```

2. Os arquivos otimizados estarão na pasta `dist/`

### Opções de Deploy

#### Vercel
1. Instale a CLI do Vercel: `npm i -g vercel`
2. Execute: `vercel`
3. Siga as instruções

#### Netlify
1. Faça upload da pasta `dist/` no painel do Netlify
2. Ou conecte o repositório Git para deploy automático

#### Outras Plataformas
- **GitHub Pages**: Configure GitHub Actions
- **Firebase Hosting**: Use `firebase deploy`
- **Surge.sh**: Execute `surge dist/`

## 🤝 Contribuindo

1. Faça um fork do projeto
2. Crie uma branch para sua feature: `git checkout -b feature/nova-feature`
3. Commit suas mudanças: `git commit -m 'Adiciona nova feature'`
4. Push para a branch: `git push origin feature/nova-feature`
5. Abra um Pull Request

## 📝 Convenções de Código

- **Componentes**: PascalCase (`BaseButton.vue`)
- **Variáveis/Funções**: camelCase (`userName`)
- **Arquivos**: kebab-case (`user-profile.ts`)
- **Commits**: Conventional Commits

## 🐛 Problemas Conhecidos

- Nenhum problema conhecido no momento

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.

## 👥 Equipe

Desenvolvido com ❤️ usando Vue.js e Tailwind CSS

---

**Versão**: 1.0.0
**Última atualização**: Dezembro 2024
